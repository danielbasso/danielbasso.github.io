library(ggplot2)
library(tidyverse)

data(midwest)
?midwest
ggplot(data = midwest, 
       mapping = aes(x = area, 
                     y = poptotal,
                     color = state,
                     size = popdensity
                     )
       ) +
  geom_label(mapping = aes(label = ifelse(poptotal > 900000, county, NA)),
             size = 2.5,
             nudge_y = 220000) +
  geom_point(alpha = 0.5) +
  scale_x_continuous(breaks = seq(0, 0.1, 0.025)) +
  scale_y_continuous(labels = scales::format_format(scientific = FALSE)) +
  labs(x = "Area",
       y = "Population",
       title = "Scatterplot",
       subtitle = "Area Vs Population",
       caption = "source: midwest")
  



