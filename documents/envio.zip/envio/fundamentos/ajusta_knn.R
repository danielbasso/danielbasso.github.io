library(caret)
library(tidyverse)

sample_size <- 150

med1_1 <- 55  
sd1_1 <- 5
med1_2 <- 30  
sd1_2 <- 10


med2_1 <- 75
sd2_1 <- 7
med2_2 <- 40  
sd2_2 <- 10

data_var1_var2 <- 
  tibble(var1 = rnorm(sample_size, med1_1, sd1_1), 
       var2 = rnorm(sample_size, med1_2, sd1_2),
      `Gênero` = "F") %>% 
  bind_rows(
  tibble(var1 = rnorm(sample_size, med2_1, sd2_1), 
         var2 = rnorm(sample_size, med2_2, sd2_2),
         `Gênero` = "M")
  )

plot_exemplo_var1_var2 <- ggplot(data_var1_var2, aes(x = var1, y = var2)) +
  geom_point(mapping = aes(color = `Gênero`)) +
  theme_bw()

plot_exemplo_var1_var2

data_var1_var2_knn_fit1 <- train(`Gênero` ~ ., data = data_var1_var2, 
                             method = "knn",
                             tuneGrid = data.frame(k = c(1))
)

data_var1_var2_knn_fit2 <- train(`Gênero` ~ ., data = data_var1_var2, 
                             method = "knn",
                             tuneGrid = data.frame(k = c(5))
)

data_var1_var2_knn_fit3 <- train(`Gênero` ~ ., data = data_var1_var2, 
                                   method = "knn",
                                   tuneGrid = data.frame(k = c(25))
)


var1_var2_grid <- expand.grid(var1 = seq(0, 100 ,0.5), var2 = seq(0, 100, 0.5))

pred_knn_fit1 <- predict(data_var1_var2_knn_fit1, newdata = var1_var2_grid, type = "prob")
pred_knn_fit2 <- predict(data_var1_var2_knn_fit2, newdata = var1_var2_grid, type = "prob")
pred_knn_fit3 <- predict(data_var1_var2_knn_fit3, newdata = var1_var2_grid, type = "prob")

var1_var2_knn1 <- var1_var2_grid %>% bind_cols(prob_F = pred_knn_fit1$F, `Gênero` = ifelse(pred_knn_fit1$F > 0.5, "F", "M"))
var1_var2_knn2 <- var1_var2_grid %>% bind_cols(prob_F = pred_knn_fit2$F, `Gênero` = ifelse(pred_knn_fit1$F > 0.5, "F", "M"))
var1_var2_knn3 <- var1_var2_grid %>% bind_cols(prob_F = pred_knn_fit3$F, `Gênero` = ifelse(pred_knn_fit1$F > 0.5, "F", "M"))

write_csv(var1_var2_knn1, "data/var1_var2_knn1.csv")
write_csv(var1_var2_knn2, "data/var1_var2_knn2.csv")
write_csv(var1_var2_knn3, "data/var1_var2_knn3.csv")


plot_exemplo_var1_var2 +
  # geom_point(data = var1_var2_knn1, mapping = aes(color = `Gênero`), alpha = 0.5)
  geom_contour(data = var1_var2_knn1, mapping = aes(z = prob_F), breaks = c(0, 0.501), alpha = 0.5)
